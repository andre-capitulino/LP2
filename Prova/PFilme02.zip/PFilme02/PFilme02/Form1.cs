﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[2, 2];
            string auxiliar = "";
            double media = 0;
            double media2 = 0;

            for (int i = 0;i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    auxiliar = Interaction.InputBox($"Pessoa {i + 1}: Digite a nota do {j + 1}º filme:", "Entrada de Dados");
                    if(auxiliar == null) { 
                        MessageBox.Show("Número inválido!");
                    } else
                    {
                        listBox1.Items.Add($"Pessoa {i + 1} Nota Filme {j + 1}: {auxiliar}");
                    }
                }
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ;
        }
    }
}
