﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482513046
{
    internal class Contato
    {
        public int IdContato { get; set; }
        public string NomeContato { get; set; }
        public string EndContato { get; set; }
        public int Cidadeidcidade { get; set; }
        public string Celcontato { get; set; }
        public string Emailcontato { get; set; }
        public DateTime Dtacasdastrocontato { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daContato;

            DataTable dtContato = new DataTable();

            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CONTATO", Form1.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtContato;
        }
        public int incluir()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO CONTATO VALUES" + "(@nomecontato,@endcontato,@cidadeidcidade," + 
                    "@celcontato,@emailcontato,@dtcadastrocontato)", Form1.conexao);

                mycommand.Parameters.Add(new SqlParameter("@NomeContato",
                  SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@EndContato",
                    SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@Cidadeidcidade",
                    SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@Celcontato",
                    SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@Emailcontato",
                    SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato",
                    SqlDbType.Date));


                mycommand.Parameters["@NomeContato"].Value = NomeContato;
                mycommand.Parameters["@EndContato"].Value = EndContato;
                mycommand.Parameters["@Cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@Celcontato"].Value = Celcontato;
                mycommand.Parameters["@Emailcontato"].Value = Emailcontato;
                mycommand.Parameters["@dtcadastrocontato"].Value = Dtacasdastrocontato;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }
        public int Alterar()
        {
            int retorno = 0; ;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE CONTATO SET NOME_CONTATO=@NomeContato," + "END_CONTATO=@EndContato," +
                    " CIDADE_ID_CIDADE=@Cidadeidcidade, CEL_CONTATO=@Celcontato," +
                    "EMAIL_CONTATO=@Emailcontato, " +
                    " DTCADASTRO_CONTATO=@Dtacasdastrocontato WHERE ID_CONTATO = @IdContato",
                    Form1.conexao);
                mycommand.Parameters.Add(new SqlParameter("@IdContato", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@NomeContato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@EndContato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@Cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@Celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@Emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@Dtacasdastrocontato", SqlDbType.Date));


                mycommand.Parameters["@IdContato"].Value = IdContato;
                mycommand.Parameters["@NomeContato"].Value = NomeContato;
                mycommand.Parameters["@EndContato"].Value = EndContato;
                mycommand.Parameters["@Cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@Celcontato"].Value = Celcontato;
                mycommand.Parameters["@Emailcontato"].Value = Emailcontato;
                mycommand.Parameters["@Dtacasdastrocontato"].Value = Dtacasdastrocontato;


                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }


        public int Excluir() 
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM CONTATO " +
                    " WHERE ID_CONTATO=@IdContato", Form1.conexao);
                mycommand.Parameters.Add(new SqlParameter("@IdContato", SqlDbType.Int));
                mycommand.Parameters["@IdContato"].Value = IdContato;

                nReg = mycommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                throw;
            }

            return nReg;
        }
    }
}
