﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PContato0030482513046
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=LAPTOP-HEF3UNBM\\SQLEXPRESS;Initial Catalog=BD;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro no Banco de dados" + ex.Message);
            }
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmContato>().Count() > 0)
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                FrmContato FRMC = new FrmContato();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close ();
        }

        private void cidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<sobre>().Count() > 0)
            {
                Application.OpenForms["sobre"].BringToFront();
            }
            else
            {
                sobre FRMC = new sobre();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }
    }
    }
