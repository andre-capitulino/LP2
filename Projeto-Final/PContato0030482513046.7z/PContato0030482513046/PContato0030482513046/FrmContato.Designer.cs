﻿namespace PContato0030482513046
{
    partial class FrmContato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmContato));
            this.bnvContato = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.tbContato = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvContato = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbxCidadeContato = new System.Windows.Forms.ComboBox();
            this.dtpdtCadastro = new System.Windows.Forms.DateTimePicker();
            this.lbDataCadastro = new System.Windows.Forms.Label();
            this.txtEmailContato = new System.Windows.Forms.TextBox();
            this.lbEmailContato = new System.Windows.Forms.Label();
            this.txtCelularContato = new System.Windows.Forms.TextBox();
            this.lbCelContato = new System.Windows.Forms.Label();
            this.lbCidadeContato = new System.Windows.Forms.Label();
            this.txtEndCadastrado = new System.Windows.Forms.TextBox();
            this.lbEndContato = new System.Windows.Forms.Label();
            this.txtNomeContato = new System.Windows.Forms.TextBox();
            this.lbContato = new System.Windows.Forms.Label();
            this.txtIDContato = new System.Windows.Forms.TextBox();
            this.lbIDContato = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bnvContato)).BeginInit();
            this.bnvContato.SuspendLayout();
            this.tbContato.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContato)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bnvContato
            // 
            this.bnvContato.AddNewItem = null;
            this.bnvContato.CountItem = this.bindingNavigatorCountItem;
            this.bnvContato.DeleteItem = null;
            this.bnvContato.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bnvContato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.btnNovo,
            this.btnAlterar,
            this.btnSalvar,
            this.btnCancelar,
            this.btnExcluir,
            this.btnSair});
            this.bnvContato.Location = new System.Drawing.Point(0, 0);
            this.bnvContato.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnvContato.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnvContato.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnvContato.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnvContato.Name = "bnvContato";
            this.bnvContato.PositionItem = this.bindingNavigatorPositionItem;
            this.bnvContato.Size = new System.Drawing.Size(1067, 27);
            this.bnvContato.TabIndex = 0;
            this.bnvContato.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(65, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // btnNovo
            // 
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(29, 24);
            this.btnNovo.Text = "Novo Registro";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Image")));
            this.btnAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(29, 24);
            this.btnAlterar.Text = "Alterar ";
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(29, 24);
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Enabled = false;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(29, 24);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(29, 24);
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(29, 24);
            this.btnSair.Text = "Sair";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // tbContato
            // 
            this.tbContato.Controls.Add(this.tabPage1);
            this.tbContato.Controls.Add(this.tabPage2);
            this.tbContato.Location = new System.Drawing.Point(52, 46);
            this.tbContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbContato.Name = "tbContato";
            this.tbContato.SelectedIndex = 0;
            this.tbContato.Size = new System.Drawing.Size(695, 313);
            this.tbContato.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvContato);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(687, 284);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dados";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvContato
            // 
            this.dgvContato.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContato.Location = new System.Drawing.Point(8, 7);
            this.dgvContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvContato.Name = "dgvContato";
            this.dgvContato.ReadOnly = true;
            this.dgvContato.RowHeadersWidth = 51;
            this.dgvContato.Size = new System.Drawing.Size(676, 273);
            this.dgvContato.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cbxCidadeContato);
            this.tabPage2.Controls.Add(this.dtpdtCadastro);
            this.tabPage2.Controls.Add(this.lbDataCadastro);
            this.tabPage2.Controls.Add(this.txtEmailContato);
            this.tabPage2.Controls.Add(this.lbEmailContato);
            this.tabPage2.Controls.Add(this.txtCelularContato);
            this.tabPage2.Controls.Add(this.lbCelContato);
            this.tabPage2.Controls.Add(this.lbCidadeContato);
            this.tabPage2.Controls.Add(this.txtEndCadastrado);
            this.tabPage2.Controls.Add(this.lbEndContato);
            this.tabPage2.Controls.Add(this.txtNomeContato);
            this.tabPage2.Controls.Add(this.lbContato);
            this.tabPage2.Controls.Add(this.txtIDContato);
            this.tabPage2.Controls.Add(this.lbIDContato);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(687, 284);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Detalhes";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cbxCidadeContato
            // 
            this.cbxCidadeContato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCidadeContato.Enabled = false;
            this.cbxCidadeContato.FormattingEnabled = true;
            this.cbxCidadeContato.Location = new System.Drawing.Point(147, 113);
            this.cbxCidadeContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxCidadeContato.MaxLength = 50;
            this.cbxCidadeContato.Name = "cbxCidadeContato";
            this.cbxCidadeContato.Size = new System.Drawing.Size(439, 24);
            this.cbxCidadeContato.TabIndex = 14;
            // 
            // dtpdtCadastro
            // 
            this.dtpdtCadastro.Enabled = false;
            this.dtpdtCadastro.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpdtCadastro.Location = new System.Drawing.Point(147, 214);
            this.dtpdtCadastro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpdtCadastro.Name = "dtpdtCadastro";
            this.dtpdtCadastro.Size = new System.Drawing.Size(236, 22);
            this.dtpdtCadastro.TabIndex = 13;
            // 
            // lbDataCadastro
            // 
            this.lbDataCadastro.AutoSize = true;
            this.lbDataCadastro.Location = new System.Drawing.Point(37, 214);
            this.lbDataCadastro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbDataCadastro.Name = "lbDataCadastro";
            this.lbDataCadastro.Size = new System.Drawing.Size(94, 16);
            this.lbDataCadastro.TabIndex = 12;
            this.lbDataCadastro.Text = "Data Cadastro";
            // 
            // txtEmailContato
            // 
            this.txtEmailContato.Enabled = false;
            this.txtEmailContato.Location = new System.Drawing.Point(147, 178);
            this.txtEmailContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEmailContato.MaxLength = 100;
            this.txtEmailContato.Name = "txtEmailContato";
            this.txtEmailContato.Size = new System.Drawing.Size(439, 22);
            this.txtEmailContato.TabIndex = 11;
            // 
            // lbEmailContato
            // 
            this.lbEmailContato.AutoSize = true;
            this.lbEmailContato.Location = new System.Drawing.Point(37, 182);
            this.lbEmailContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbEmailContato.Name = "lbEmailContato";
            this.lbEmailContato.Size = new System.Drawing.Size(41, 16);
            this.lbEmailContato.TabIndex = 10;
            this.lbEmailContato.Text = "Email";
            // 
            // txtCelularContato
            // 
            this.txtCelularContato.Enabled = false;
            this.txtCelularContato.Location = new System.Drawing.Point(147, 146);
            this.txtCelularContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCelularContato.MaxLength = 15;
            this.txtCelularContato.Name = "txtCelularContato";
            this.txtCelularContato.Size = new System.Drawing.Size(236, 22);
            this.txtCelularContato.TabIndex = 9;
            // 
            // lbCelContato
            // 
            this.lbCelContato.AutoSize = true;
            this.lbCelContato.Location = new System.Drawing.Point(37, 150);
            this.lbCelContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCelContato.Name = "lbCelContato";
            this.lbCelContato.Size = new System.Drawing.Size(49, 16);
            this.lbCelContato.TabIndex = 8;
            this.lbCelContato.Text = "Celular";
            // 
            // lbCidadeContato
            // 
            this.lbCidadeContato.AutoSize = true;
            this.lbCidadeContato.Location = new System.Drawing.Point(37, 118);
            this.lbCidadeContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCidadeContato.Name = "lbCidadeContato";
            this.lbCidadeContato.Size = new System.Drawing.Size(51, 16);
            this.lbCidadeContato.TabIndex = 6;
            this.lbCidadeContato.Text = "Cidade";
            // 
            // txtEndCadastrado
            // 
            this.txtEndCadastrado.Enabled = false;
            this.txtEndCadastrado.Location = new System.Drawing.Point(147, 82);
            this.txtEndCadastrado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEndCadastrado.MaxLength = 100;
            this.txtEndCadastrado.Name = "txtEndCadastrado";
            this.txtEndCadastrado.Size = new System.Drawing.Size(439, 22);
            this.txtEndCadastrado.TabIndex = 5;
            // 
            // lbEndContato
            // 
            this.lbEndContato.AutoSize = true;
            this.lbEndContato.Location = new System.Drawing.Point(37, 86);
            this.lbEndContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbEndContato.Name = "lbEndContato";
            this.lbEndContato.Size = new System.Drawing.Size(66, 16);
            this.lbEndContato.TabIndex = 4;
            this.lbEndContato.Text = "Endereço";
            // 
            // txtNomeContato
            // 
            this.txtNomeContato.Enabled = false;
            this.txtNomeContato.Location = new System.Drawing.Point(147, 50);
            this.txtNomeContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNomeContato.MaxLength = 50;
            this.txtNomeContato.Name = "txtNomeContato";
            this.txtNomeContato.Size = new System.Drawing.Size(439, 22);
            this.txtNomeContato.TabIndex = 3;
            // 
            // lbContato
            // 
            this.lbContato.AutoSize = true;
            this.lbContato.Location = new System.Drawing.Point(37, 54);
            this.lbContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbContato.Name = "lbContato";
            this.lbContato.Size = new System.Drawing.Size(44, 16);
            this.lbContato.TabIndex = 2;
            this.lbContato.Text = "Nome";
            // 
            // txtIDContato
            // 
            this.txtIDContato.Enabled = false;
            this.txtIDContato.Location = new System.Drawing.Point(147, 18);
            this.txtIDContato.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtIDContato.Name = "txtIDContato";
            this.txtIDContato.Size = new System.Drawing.Size(439, 22);
            this.txtIDContato.TabIndex = 1;
            // 
            // lbIDContato
            // 
            this.lbIDContato.AutoSize = true;
            this.lbIDContato.Location = new System.Drawing.Point(37, 22);
            this.lbIDContato.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbIDContato.Name = "lbIDContato";
            this.lbIDContato.Size = new System.Drawing.Size(20, 16);
            this.lbIDContato.TabIndex = 0;
            this.lbIDContato.Text = "ID";
            // 
            // FrmContato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbContato);
            this.Controls.Add(this.bnvContato);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmContato";
            this.Text = "FrmContato";
            this.Load += new System.EventHandler(this.FrmContato_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bnvContato)).EndInit();
            this.bnvContato.ResumeLayout(false);
            this.bnvContato.PerformLayout();
            this.tbContato.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContato)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bnvContato;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TabControl tbContato;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnAlterar;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.DataGridView dgvContato;
        private System.Windows.Forms.Label lbIDContato;
        private System.Windows.Forms.Label lbDataCadastro;
        private System.Windows.Forms.TextBox txtEmailContato;
        private System.Windows.Forms.Label lbEmailContato;
        private System.Windows.Forms.TextBox txtCelularContato;
        private System.Windows.Forms.Label lbCelContato;
        private System.Windows.Forms.Label lbCidadeContato;
        private System.Windows.Forms.TextBox txtEndCadastrado;
        private System.Windows.Forms.Label lbEndContato;
        private System.Windows.Forms.TextBox txtNomeContato;
        private System.Windows.Forms.Label lbContato;
        private System.Windows.Forms.TextBox txtIDContato;
        private System.Windows.Forms.DateTimePicker dtpdtCadastro;
        private System.Windows.Forms.ComboBox cbxCidadeContato;
    }
}